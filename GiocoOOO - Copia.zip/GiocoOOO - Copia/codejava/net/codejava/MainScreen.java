package net.codejava;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import javax.swing.Timer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.*;
import javax.swing.text.JTextComponent;

import java.util.*;

import java.applet.*;

public class MainScreen extends JFrame{
		
	//DICHIARIAMO I COMPONENTI
	private JLabel titleLabel, campo1;
	private JButton newGameButton, visualCreditsButton, buyCreditsButton,exitButton;
	private Timer timer;
	private ImageIcon imageicon;
	private JPanel panel;
	
	private int x, y;
	private int z=50;
	private int e=50;
	
	
	public MainScreen() {
		
		//INIZIALIZZAZIONE DEI COMPONENTI
		titleLabel = new JLabel("SUPER FOX RUN");
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setVerticalAlignment(SwingConstants.CENTER);
		Font font1	= new Font("Comic Sans MS", Font.PLAIN, 50);
		titleLabel.setFont(font1);
		titleLabel.setForeground(Color.RED);
        Font labelFont = titleLabel.getFont();
        int labelFontSize = labelFont.getSize() + 45;
        Font newFont = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        titleLabel.setFont(newFont);
        Font newFont2 = new Font("Comic Sans MS", Font.BOLD, 50);
        titleLabel.setFont(newFont2);
		
		newGameButton = new JButton("NEW GAME");
		Font buttonFont = new Font("Comic Sans MS", Font.BOLD, 50);
		newGameButton.setFont(buttonFont);
		newGameButton.setOpaque(false);
		newGameButton.setContentAreaFilled(false);
		newGameButton.setBorderPainted(false);
		newGameButton.setFocusPainted(false);
        //menu.setForeground(new Color(0, 0, 0, 0)); // Imposta il colore del testo come trasparente
		newGameButton.setVisible(true);
		newGameButton.addMouseListener(new MouseListener() {
            public void mouseEntered(MouseEvent e) {
            	newGameButton.setForeground(Color.RED);
            	Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 70);
                newGameButton.setFont(buttonFont2);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
            	newGameButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mousePressed(MouseEvent e) {
            	newGameButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseReleased(MouseEvent e) {
            	newGameButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseExited(MouseEvent e) {
            	newGameButton.setForeground(Color.BLACK);
            	Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 50);
                newGameButton.setFont(buttonFont2);
            }
        }
                );
		
		
		visualCreditsButton = new JButton("CREATORI");
		Font buttonFont1 = new Font("Comic Sans MS", Font.BOLD, 50);
		visualCreditsButton.setFont(buttonFont1);
		visualCreditsButton.setOpaque(false);
		visualCreditsButton.setContentAreaFilled(false);
		visualCreditsButton.setBorderPainted(false);
		visualCreditsButton.setFocusPainted(false);
        //menu.setForeground(new Color(0, 0, 0, 0)); // Imposta il colore del testo come trasparente
		visualCreditsButton.setVisible(true);
		visualCreditsButton.addMouseListener(new MouseListener() {
            public void mouseEntered(MouseEvent e) {
            	visualCreditsButton.setForeground(Color.RED);
            	Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 70);
                visualCreditsButton.setFont(buttonFont2);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
            	visualCreditsButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mousePressed(MouseEvent e) {
            	visualCreditsButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseReleased(MouseEvent e) {
            	visualCreditsButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseExited(MouseEvent e) {
            	visualCreditsButton.setForeground(Color.BLACK);
            	Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 50);
                visualCreditsButton.setFont(buttonFont2);
            }
        }
                );
		
		buyCreditsButton = new JButton("BUY CREDITS");
		Font buttonFont2 = new Font("Comic Sans MS", Font.BOLD, 50);
		buyCreditsButton.setFont(buttonFont2);
		buyCreditsButton.setOpaque(false);
		buyCreditsButton.setContentAreaFilled(false);
		buyCreditsButton.setBorderPainted(false);
		buyCreditsButton.setFocusPainted(false);
        //menu.setForeground(new Color(0, 0, 0, 0)); // Imposta il colore del testo come trasparente
		buyCreditsButton.setVisible(true);
		buyCreditsButton.addMouseListener(new MouseListener() {
            public void mouseEntered(MouseEvent e) {
            	buyCreditsButton.setForeground(Color.RED);
            	Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 70);
                buyCreditsButton.setFont(buttonFont2);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
            	buyCreditsButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mousePressed(MouseEvent e) {
            	buyCreditsButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseReleased(MouseEvent e) {
            	buyCreditsButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseExited(MouseEvent e) {
            	buyCreditsButton.setForeground(Color.BLACK);
            	Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 50);
                buyCreditsButton.setFont(buttonFont2);
            }
        }
                );
		
		
		
		exitButton = new JButton("EXIT");
		Font buttonFont3 = new Font("Comic Sans MS", Font.BOLD, 50);
		exitButton.setFont(buttonFont3);
		exitButton.setOpaque(false);
		exitButton.setContentAreaFilled(false);
		exitButton.setBorderPainted(false);
		exitButton.setFocusPainted(false);
        //menu.setForeground(new Color(0, 0, 0, 0)); // Imposta il colore del testo come trasparente
		exitButton.setVisible(true);
		exitButton.addMouseListener(new MouseListener() {
            public void mouseEntered(MouseEvent e) {
            	exitButton.setForeground(Color.RED);
            	Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 70);
                exitButton.setFont(buttonFont2);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
            	exitButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mousePressed(MouseEvent e) {
            	exitButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseReleased(MouseEvent e) {
            	exitButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseExited(MouseEvent e) {
            	exitButton.setForeground(Color.BLACK);
            	Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 50);
                exitButton.setFont(buttonFont2);
            }
        }
                );
		
		campo1 = new JLabel("Copyright Â©");
		
		
		//AGGIUNTA DEI COMPONENTI
		panel = new JPanel(new GridLayout(6,1)) {
			
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Disegno dell'immagine nella nuova posizione
                g.drawImage(imageicon.getImage(), -x, y, null);
                g.drawImage(imageicon.getImage(), getWidth() - x, y, null);
            }


            @Override
            public Dimension getPreferredSize() {
                return new Dimension(imageicon.getIconWidth(), imageicon.getIconHeight());
            }
        };

        ImageIcon icona = new ImageIcon("SfondoVolpe.jpg");
        setIconImage(icona.getImage());
        setTitle("FoxGame");
        setSize(1180, 820);

        this.imageicon = new ImageIcon("SfondoVolpe.jpg");
        this.x = 0;
        this.y = 0;

        timer = new Timer(10, e -> {
            x++;
            if (x > imageicon.getIconWidth()) {
                x = 0;
            }
            panel.repaint();
        });

        timer.start();
		
		panel.add(titleLabel);
		panel.add(newGameButton);
		panel.add(visualCreditsButton);
		panel.add(buyCreditsButton);
		panel.add(exitButton);
		panel.add(campo1);
		add(panel);
		
		//SETTAGGIO DIMENSIONI DELLA FINESTRA
		setTitle("FOX GAMES");
		setSize(1180,820);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		
		//BOTTONE EXIT
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		}
				);
		
		buyCreditsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				new AggiungiCrediti();
			}
		}
				);
		visualCreditsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				new ViewCredits();
			}
		}
				);
		
		newGameButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Jumping2 game = new Jumping2();
				JFrame frame = new JFrame("Jumping Fox Game");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setResizable(false);
				frame.setContentPane(game);
				frame.pack();
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			}
		}
				);
				
	}
	
	public static void main(String[] args) {
		new MainScreen();
	}
	
}