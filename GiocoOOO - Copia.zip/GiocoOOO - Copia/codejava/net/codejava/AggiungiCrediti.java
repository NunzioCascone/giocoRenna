package net.codejava;

import javax.sound.sampled.AudioInputStream;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import javax.swing.Timer;
import javax.swing.border.Border;

import java.awt.*;
import java.io.File;
import java.awt.event.*;
import javax.swing.text.JTextComponent;
import java.util.*;

import java.applet.*;

import java.sql.*;

public class AggiungiCrediti extends JFrame{
	
	ArrayList<Integer> crediti = new ArrayList<Integer>();
	
	private static final String DB_URL = "jdbc:mysql://localhost/giocoRenna";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "Davide123@";	
	
	private JLabel addCreditsLabel;
	private JTextField addCreditsField;
	private JButton aggiungi,visualizza,indietro;
	private JTextArea visualizzaCrediti;
	
	
	private Timer timer;
	private ImageIcon imageicon;
	private int x, y;
	
	public AggiungiCrediti() {
		
		addCreditsLabel = new JLabel("Aggiungi Crediti");
		addCreditsLabel.setForeground(Color.RED);
        addCreditsLabel.setHorizontalAlignment(SwingConstants.CENTER);
        addCreditsLabel.setVerticalAlignment(SwingConstants.CENTER);
        Font labelFont = addCreditsLabel.getFont();
        int labelFontSize = labelFont.getSize() + 45;
        Font newFont = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        addCreditsLabel.setFont(newFont);
        Font newFont2 = new Font("Comic Sans MS", Font.BOLD, 70);
        addCreditsLabel.setFont(newFont2);
        
		addCreditsField = new JTextField();
		Font font = new Font("Arial", Font.PLAIN, 50);
        addCreditsField.setFont(font);
        addCreditsField.setAlignmentX(Component.CENTER_ALIGNMENT);
        addCreditsField.setAlignmentY(Component.CENTER_ALIGNMENT);
        addCreditsField.setOpaque(false);
		Border border = BorderFactory.createLineBorder(Color.RED);
		addCreditsField.setBorder(border);
		addCreditsField.setHorizontalAlignment(SwingConstants.CENTER);
		
		aggiungi = new JButton("Compra");
		aggiungi.setOpaque(false);
		aggiungi.setContentAreaFilled(false);
		aggiungi.setBorderPainted(false);
		aggiungi.setFocusPainted(false);
		aggiungi.setVisible(true);
		aggiungi.addMouseListener(new MouseListener() {
        	public void mouseEntered(MouseEvent e) {
        		aggiungi.setForeground(Color.RED);
        		Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 70);
        		aggiungi.setFont(buttonFont2);
        	}

			@Override
			public void mouseClicked(MouseEvent e) {
				aggiungi.setBackground(new Color(0,0,0,0));
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				aggiungi.setBackground(new Color(0,0,0,0));
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				aggiungi.setBackground(new Color(0,0,0,0));
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				aggiungi.setForeground(Color.BLACK);
				Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 50);
				aggiungi.setFont(buttonFont2);
				
			}
        }
        		);
		Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 50);
        aggiungi.setFont(buttonFont2);
		
		visualizza = new JButton("Visualizza Crediti");
		visualizza.setOpaque(false);
		visualizza.setContentAreaFilled(false);
		visualizza.setBorderPainted(false);
		visualizza.setFocusPainted(false);
        //menu.setForeground(new Color(0, 0, 0, 0)); // Imposta il colore del testo come trasparente
		visualizza.setVisible(true);
		visualizza.addMouseListener(new MouseListener() {
        	public void mouseEntered(MouseEvent e) {
        		visualizza.setForeground(Color.RED);
        		Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 70);
        		visualizza.setFont(buttonFont2);
        	}

			@Override
			public void mouseClicked(MouseEvent e) {
				visualizza.setBackground(new Color(0,0,0,0));
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				visualizza.setBackground(new Color(0,0,0,0));
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				visualizza.setBackground(new Color(0,0,0,0));
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				visualizza.setForeground(Color.BLACK);
				Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 50);
				visualizza.setFont(buttonFont2);
				
			}
        }
        		);
		Font buttonFont3= new Font("Comic Sans MS", Font.BOLD, 50);
        visualizza.setFont(buttonFont3);
        
        indietro = new JButton("Menu");
        indietro.setOpaque(false);
		indietro.setContentAreaFilled(false);
		indietro.setBorderPainted(false);
		indietro.setFocusPainted(false);
		indietro.setVisible(true);
		indietro.addMouseListener(new MouseListener() {
        	public void mouseEntered(MouseEvent e) {
        		indietro.setForeground(Color.RED);
        		Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 70);
        		indietro.setFont(buttonFont2);
        	}

			@Override
			public void mouseClicked(MouseEvent e) {
				indietro.setBackground(new Color(0,0,0,0));
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				indietro.setBackground(new Color(0,0,0,0));
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				indietro.setBackground(new Color(0,0,0,0));
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				indietro.setForeground(Color.BLACK);
				Font buttonFont2= new Font("Comic Sans MS", Font.BOLD, 50);
				indietro.setFont(buttonFont2);
				
			}
        }
        		);
		Font buttonFont4= new Font("Comic Sans MS", Font.BOLD, 50);
        indietro.setFont(buttonFont4);
		
		visualizzaCrediti = new JTextArea();
		Font font2 = new Font("Comic Sans MS", Font.PLAIN, 50);
        visualizzaCrediti.setFont(font2);
        visualizzaCrediti.setAlignmentX(Component.CENTER_ALIGNMENT);
        visualizzaCrediti.setAlignmentY(Component.CENTER_ALIGNMENT);
		visualizzaCrediti.setOpaque(false);
        //menu.setForeground(new Color(0, 0, 0, 0)); // Imposta il colore del testo come trasparente
		visualizzaCrediti.setVisible(true);
		Border border2 = BorderFactory.createLineBorder(Color.RED);
		visualizzaCrediti.setBorder(border2);
		visualizzaCrediti.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		JPanel panel = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				ImageIcon imageIcon = new ImageIcon("C:\\Users\\peppe\\eclipse-workspace\\ProgettoGruppoGiocoFox\\Shop.jpg");
				Image image = imageIcon.getImage();
				g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
			}
		};
		panel.setLayout(new GridLayout(6,1));
	        
		ImageIcon icona = new ImageIcon("C:\\Users\\peppe\\eclipse-workspace\\ProgettoGruppoGiocoFox\\images.png");
	    setIconImage(icona.getImage());
	    setTitle("Menu Principale");
		setSize(1180,820);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	        panel.add(addCreditsLabel);
	        panel.add(addCreditsField);
	        panel.add(aggiungi);
	        panel.add(visualizza);
	        panel.add(visualizzaCrediti);
	        panel.add(indietro);
	        
	        aggiungi.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                Connection conn = null;
	                PreparedStatement stmt1 = null;
	                PreparedStatement stmt2 = null;
	                String sql1 = "SELECT crediti FROM partita WHERE id=1";
	                String sql2 = "UPDATE partita SET crediti = ? WHERE id=1";
	                try {
	                    conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	                    
	                    stmt1 = conn.prepareStatement(sql1);
	                    ResultSet rs = stmt1.executeQuery();
	                    
	                    int creditiAttuali = 0;
	                    if (rs.next()) {
	                        creditiAttuali = rs.getInt("crediti");
	                    }
	                    
	                    String creditiDaAggiungere = addCreditsField.getText();
	                    int creditiAggiunti = Integer.parseInt(creditiDaAggiungere);
	                    

	                    int nuoviCrediti = creditiAttuali + creditiAggiunti;
	                    
	                    stmt2 = conn.prepareStatement(sql2);
	                    stmt2.setInt(1, nuoviCrediti);
	                    stmt2.executeUpdate();
	                    
	                    addCreditsField.setText("");
	                    
	                    stmt1.close();
	                    stmt2.close();
	                    conn.close();
	                } catch (SQLException e1) {
	                    e1.printStackTrace();
	                }
	            }
	        });

	       
	        
	        visualizza.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                Connection conn = null;
	                PreparedStatement stmt = null;
	                String sql = "SELECT crediti FROM partita WHERE id=1";

	                try {
	                    conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	                    stmt = conn.prepareStatement(sql);
	                    ResultSet rs = stmt.executeQuery();

	                    int somma = 0;
	                    while (rs.next()) {
	                        int creditii = rs.getInt("crediti");
	                        crediti.add(creditii);
	                        somma += creditii;
	                    }

	                    rs.close();
	                    stmt.close();
	                    conn.close();

	                    String str1 = Integer.toString(somma);
	                    visualizzaCrediti.setText(str1);

	                } catch (SQLException e1) {
	                    e1.printStackTrace();
	                }
	            }
	        });
	        
	        indietro.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new MainScreen();
	        		dispose();
	        		
	        	}
	        }
	        		);
	        
	        add(panel);
	        setVisible(true);
	        
		
	}
}