package net.codejava;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.applet.*;



public class ViewCredits extends JFrame{
	
	private JLabel visualizationCredits, author1, author2, author3, author4, author5, author6, author7, author8,supervisorLabel;
	private JPanel panel;
	private JButton backButton;
	private Timer timer;
	private ImageIcon imageicon;
	
	private int x, y;
	private int z=50;
	private int e=50;
	
	
	public ViewCredits() {
		
		
		
		
		visualizationCredits = new JLabel("Author: ");
		visualizationCredits.setHorizontalAlignment(SwingConstants.CENTER);
		visualizationCredits.setVerticalAlignment(SwingConstants.CENTER);
		Font font1	= new Font("Comic Sans MS", Font.PLAIN, 50);
		visualizationCredits.setFont(font1);
		visualizationCredits.setForeground(Color.YELLOW);
        Font labelFont = visualizationCredits.getFont();
        int labelFontSize = labelFont.getSize() + 45;
        Font newFont = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        visualizationCredits.setFont(newFont);
        Font newFont2 = new Font("Comic Sans MS", Font.BOLD, 50);
        visualizationCredits.setFont(newFont2);
		
		author1 = new JLabel("Pietro Latorre");
		author1.setHorizontalAlignment(SwingConstants.CENTER);
		author1.setVerticalAlignment(SwingConstants.CENTER);
		Font font	= new Font("Comic Sans MS", Font.PLAIN, 50);
		author1.setFont(font1);
		author1.setForeground(Color.RED);
        Font labelFont1 = author1.getFont();
        int labelFontSize1= labelFont.getSize() + 45;
        Font newFont1 = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        author1.setFont(newFont);
        Font newFont3 = new Font("Comic Sans MS", Font.BOLD, 50);
        author1.setFont(newFont2);
		
		author2 = new JLabel("Salvatore Formicola");
		author2.setHorizontalAlignment(SwingConstants.CENTER);
		author2.setVerticalAlignment(SwingConstants.CENTER);
		Font font3	= new Font("Comic Sans MS", Font.PLAIN, 50);
		author2.setFont(font1);
		author2.setForeground(Color.RED);
        Font labelFont2 = author2.getFont();
        int labelFontSize2= labelFont.getSize() + 45;
        Font newFont4 = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        author2.setFont(newFont);
        Font newFont5 = new Font("Comic Sans MS", Font.BOLD, 50);
        author2.setFont(newFont2);
		
		author3 = new JLabel("Giuseppe Fornaro");
		author3.setHorizontalAlignment(SwingConstants.CENTER);
		author3.setVerticalAlignment(SwingConstants.CENTER);
		Font font5	= new Font("Comic Sans MS", Font.PLAIN, 50);
		author3.setFont(font1);
		author3.setForeground(Color.RED);
        Font labelFont5 = author3.getFont();
        int labelFontSize5= labelFont.getSize() + 45;
        Font newFont6 = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        author3.setFont(newFont);
        Font newFont7 = new Font("Comic Sans MS", Font.BOLD, 50);
        author3.setFont(newFont2);
		
		author4 = new JLabel("Nunzio Cascone");
		author4.setHorizontalAlignment(SwingConstants.CENTER);
		author4.setVerticalAlignment(SwingConstants.CENTER);
		Font font6	= new Font("Comic Sans MS", Font.PLAIN, 50);
		author4.setFont(font1);
		author4.setForeground(Color.RED);
        Font labelFont6 = author4.getFont();
        int labelFontSize6= labelFont.getSize() + 45;
        Font newFont8 = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        author4.setFont(newFont);
        Font newFont9 = new Font("Comic Sans MS", Font.BOLD, 50);
        author4.setFont(newFont2);
		
		author5 = new JLabel("Antonina Parisi");
		author5.setHorizontalAlignment(SwingConstants.CENTER);
		author5.setVerticalAlignment(SwingConstants.CENTER);
		Font font7	= new Font("Comic Sans MS", Font.PLAIN, 50);
		author5.setFont(font1);
		author5.setForeground(Color.RED);
        Font labelFont7 = author5.getFont();
        int labelFontSize7= labelFont.getSize() + 45;
        Font newFont0 = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        author5.setFont(newFont);
        Font newFont10 = new Font("Comic Sans MS", Font.BOLD, 50);
        author5.setFont(newFont2);
		
		author6 = new JLabel("Nicola Tango");
		author6.setHorizontalAlignment(SwingConstants.CENTER);
		author6.setVerticalAlignment(SwingConstants.CENTER);
		Font font8	= new Font("Comic Sans MS", Font.PLAIN, 50);
		author6.setFont(font1);
		author6.setForeground(Color.RED);
        Font labelFont8 = author6.getFont();
        int labelFontSize8= labelFont.getSize() + 45;
        Font newFont11 = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        author6.setFont(newFont);
        Font newFont12 = new Font("Comic Sans MS", Font.BOLD, 50);
        author6.setFont(newFont2);
		
		author7 = new JLabel("Michelangelo Tundo");
		author7.setHorizontalAlignment(SwingConstants.CENTER);
		author7.setVerticalAlignment(SwingConstants.CENTER);
		Font font9	= new Font("Comic Sans MS", Font.PLAIN, 50);
		author7.setFont(font1);
		author7.setForeground(Color.RED);
        Font labelFont9 = author7.getFont();
        int labelFontSize9= labelFont.getSize() + 45;
        Font newFont13 = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        author7.setFont(newFont);
        Font newFont14 = new Font("Comic Sans MS", Font.BOLD, 50);
        author7.setFont(newFont2);
		
		author8 = new JLabel("Fabrizio D'Adamo");
		supervisorLabel = new JLabel("Con la supervisione di: Fabrizio D'Adamo");
		supervisorLabel.setHorizontalAlignment(SwingConstants.CENTER);
		supervisorLabel.setVerticalAlignment(SwingConstants.CENTER);
		Font font10	= new Font("Comic Sans MS", Font.PLAIN, 50);
		supervisorLabel.setFont(font1);
		supervisorLabel.setForeground(Color.BLUE);
        Font labelFont10 = supervisorLabel.getFont();
        int labelFontSize10= labelFont.getSize() + 45;
        Font newFont15 = new Font(labelFont.getName(), labelFont.getStyle(), labelFontSize);
        supervisorLabel.setFont(newFont);
        Font newFont16 = new Font("Comic Sans MS", Font.BOLD, 50);
        supervisorLabel.setFont(newFont2);
	
		
        backButton = new JButton("Menu");
        Font buttonFont1 = new Font("Comic Sans MS", Font.BOLD, 50);
        backButton.setFont(buttonFont1);
        backButton.setOpaque(false);
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);
        backButton.setFocusPainted(false);
        //menu.setForeground(new Color(0, 0, 0, 0)); // Imposta il colore del testo come trasparente
        backButton.setVisible(true);
        backButton.addMouseListener(new MouseListener() {
            public void mouseEntered(MouseEvent e) {
            	backButton.setForeground(Color.RED);
            	Font buttonFont1 = new Font("Comic Sans MS", Font.BOLD, 70);
            	backButton.setFont(buttonFont1);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
            	backButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mousePressed(MouseEvent e) {
            	backButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseReleased(MouseEvent e) {
            	backButton.setBackground(new Color(0,0,0,0));

            }

            @Override
            public void mouseExited(MouseEvent e) {
            	backButton.setForeground(Color.BLACK);
            	Font buttonFont1 = new Font("Comic Sans MS", Font.BOLD, 50);
            	backButton.setFont(buttonFont1);

            }
        }
                );
		
       
        
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon imageIcon = new ImageIcon("Renna.gif");
                Image image = imageIcon.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panel.setLayout(new GridLayout(10,1));
		
		panel.add(visualizationCredits);
		panel.add(author1);
		panel.add(author2);
		panel.add(author3);
		panel.add(author4);
		panel.add(author5);
		panel.add(author6);
		panel.add(author7);
		panel.add(supervisorLabel);
		panel.add(backButton);
		add(panel);
		
		setTitle("Credits");
		setSize(1180,820);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		backButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainScreen();
				dispose();
			}
		}
				);
		
	}
	
}



