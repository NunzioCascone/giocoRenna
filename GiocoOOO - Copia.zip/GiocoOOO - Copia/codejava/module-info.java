/**
 * 
 */
/**
 * @author Nunzioo
 *
 */
module GiocoOOO {
	requires java.desktop;
	requires java.sql;
}